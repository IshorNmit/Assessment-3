vti_encoding:SR|utf8-nl
vti_author:SR|ISHOR\\Dell
vti_modifiedby:SR|ISHOR\\Dell
vti_timelastmodified:TR|10 Sep 2018 23:43:20 -0000
vti_timecreated:TR|10 Sep 2018 23:43:01 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|index1.html
vti_nexttolasttimemodified:TR|10 Sep 2018 23:43:16 -0000
vti_cacheddtm:TX|10 Sep 2018 23:43:20 -0000
vti_filesize:IR|3
